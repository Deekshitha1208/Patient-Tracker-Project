package com.cts.newproject.dao;

import com.cts.newproject.model.DoctorLogin;

public class DoctorDaoImpl implements DoctorDao {

	@Override
	
		public int doctorLogin(DoctorLogin login) {
			String username=login.getUsername();
			String password=login.getPasword();
			if(username.equals("doctor")&&password.equals("doctor"))
				return 1;
			else
				return 0;
	}

}



