package com.cts.newproject.dao;
import com.cts.newproject.model.DoctorLogin;
import com.cts.newproject.model.DoctorRegistration;

public interface DoctorRegi {
	int doctorRegister(DoctorRegistration register);


}

