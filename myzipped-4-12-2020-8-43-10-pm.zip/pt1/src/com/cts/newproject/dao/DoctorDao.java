package com.cts.newproject.dao;
import com.cts.newproject.model.DoctorLogin;
public interface DoctorDao {
	int doctorLogin(DoctorLogin login);
	}