package com.cts.newproject.dao;
import com.cts.newproject.model.AdminLogin;
import com.cts.newproject.model.AdminRegistration;

public interface AdminRegi {
	int adminRegister(AdminRegistration register);


}

