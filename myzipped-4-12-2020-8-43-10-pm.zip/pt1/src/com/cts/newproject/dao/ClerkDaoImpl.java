package com.cts.newproject.dao;

import com.cts.newproject.model.ClerkLogin;

public class ClerkDaoImpl implements ClerkDao {

	@Override
	public int clerkLogin(ClerkLogin login) {
		String username=login.getUsername();
		String password=login.getPasword();
		if(username.equals("clerk")&&password.equals("clerk"))
			return 1;
		else
			return 0;
	}


}
