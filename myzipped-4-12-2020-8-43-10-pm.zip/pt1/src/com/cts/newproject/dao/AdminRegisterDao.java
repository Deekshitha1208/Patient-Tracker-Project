package com.cts.newproject.dao;

import java.sql.PreparedStatement;
import com.cts.newproject.model.AdminLogin;
import com.cts.newproject.model.AdminRegistration;
import com.cts.newproject.util.ConnectionHandler;
import java.sql.Connection;

public class AdminRegisterDao implements AdminRegi {
	Connection con=null;
	PreparedStatement preparedStatement=null;
	@Override
	public int adminRegister(AdminRegistration register) {
		String fname=register.getFirstname();
		String lname=register.getLastname();
		int age=register.getAge();
		String gender=register.getGender();
		long phone=register.getPhone();
		String id=register.getId();
		String password=register.getPassword();
		
		//System.out.println(username);
		con=ConnectionHandler.getConnection();
		try{
			
			preparedStatement=((java.sql.Connection) con).prepareStatement("insert into admin values (mysql.nextval,?,?,?,?)");
		//	System.out.println("line 20 in admindaoimpl");
			preparedStatement.setString(2, fname);
			preparedStatement.setString(3, lname);
			preparedStatement.setString(5, gender);
			preparedStatement.setInt(4, age);
			preparedStatement.setLong(6, phone);
			preparedStatement.setString(7,id);
			preparedStatement.setString(8,password);
			preparedStatement.executeUpdate();
		}
		catch(Exception e)
		{}
		return 1;
	}
	
	}

