package com.cts.newproject.dao;

import com.cts.newproject.model.ClerkRegistration;

public interface ClerkRegi {
	int clerkRegister(ClerkRegistration register);
}