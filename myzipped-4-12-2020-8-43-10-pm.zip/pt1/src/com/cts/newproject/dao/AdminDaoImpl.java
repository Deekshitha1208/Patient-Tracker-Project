package com.cts.newproject.dao;

import com.cts.newproject.model.AdminLogin;

public class AdminDaoImpl implements AdminDao {

	@Override
	
		public int adminLogin(AdminLogin login) {
			String username=login.getUsername();
			String password=login.getPasword();
			if(username.equals("admin")&&password.equals("admin"))
				return 1;
			else
				return 0;
	}

}



