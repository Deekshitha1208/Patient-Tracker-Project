package com.cts.newproject.dao;
import com.cts.newproject.model.AdminLogin;
public interface AdminDao {
	int adminLogin(AdminLogin login);
	}