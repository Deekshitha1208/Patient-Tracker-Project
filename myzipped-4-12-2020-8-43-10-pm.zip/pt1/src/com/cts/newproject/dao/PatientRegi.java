package com.cts.newproject.dao;

import com.cts.newproject.model.PatientRegistration;

public interface PatientRegi {
int patientRegister(PatientRegistration register);

}
