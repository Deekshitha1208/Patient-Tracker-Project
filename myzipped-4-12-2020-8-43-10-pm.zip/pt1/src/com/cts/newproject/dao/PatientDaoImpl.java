package com.cts.newproject.dao;

import com.cts.newproject.model.PatientLogin;

public class PatientDaoImpl implements PatientDao {
@Override

public int patientLogin(PatientLogin login) {
String username=login.getUsername();
String password=login.getPasword();
if(username.equals("patient")&&password.equals("patient"))
return 1;
else
return 0;
}

}


