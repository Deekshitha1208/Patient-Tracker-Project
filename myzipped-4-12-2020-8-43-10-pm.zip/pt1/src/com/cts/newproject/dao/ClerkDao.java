package com.cts.newproject.dao;

import com.cts.newproject.model.ClerkLogin;

public interface ClerkDao {
	int clerkLogin(ClerkLogin login);
}
