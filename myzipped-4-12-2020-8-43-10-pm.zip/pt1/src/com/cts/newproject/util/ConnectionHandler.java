package com.cts.newproject.util;
import java.sql.DriverManager;

import java.sql.Connection;


public class ConnectionHandler {
	public static Connection getConnection(){
		Connection con=null;
		try{
			Class.forName("com.mysql.jdbc.Driver");
			System.out.println("con Hnadler");
			con=(Connection) DriverManager.getConnection("jdbc:mysql://localhost:3306/project2","root","Deekshu@143");
		}
		catch(Exception e){}
		
		return con;
	}

}

