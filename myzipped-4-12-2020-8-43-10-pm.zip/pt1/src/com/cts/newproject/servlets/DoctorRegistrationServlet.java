package com.cts.newproject.servlets;
import java.io.IOException;
import java.io.PrintWriter;
import java.sql.DriverManager;
import java.sql.Statement;

import javax.servlet.ServletException;
import javax.servlet.annotation.WebServlet;
import javax.servlet.http.HttpServlet;
import javax.servlet.http.HttpServletRequest;
import javax.servlet.http.HttpServletResponse;

import com.cts.newproject.dao.AdminRegi;
import com.cts.newproject.dao.AdminRegisterDao;
import com.cts.newproject.model.AdminRegistration;
//import com.mysql.cj.jdbc.StatementImpl;
import java.sql.Connection;
@WebServlet("/DoctorRegistration")
public class DoctorRegistrationServlet extends HttpServlet {
	private static final long serialVersionUID = 1L;
    public DoctorRegistrationServlet() {
        super();
    }
	protected void doGet(HttpServletRequest request, HttpServletResponse response) throws ServletException, IOException {
		PrintWriter out=response.getWriter();
		System.out.println("LIne 27");
		String url,name,pass;
		Connection con=null;
		String fname=request.getParameter("fname");
		String lname=request.getParameter("lname");
		int age=Integer.parseInt(request.getParameter("age"));
		String gender=request.getParameter("gender");
		long phno=Long.parseLong(request.getParameter("phono"));
		String id=request.getParameter("id");
		String pwd=request.getParameter("pwd");
		
		try{
			Class.forName("com.mysql.jdbc.Driver");
			System.out.println("LIne 38");
			url="jdbc:mysql://localhost:3306/project2";
			name="root";
			pass="Deekshu@143";
			 con=DriverManager.getConnection(url,name,pass);
			Statement st= ((java.sql.Connection) con).createStatement();
			System.out.println("LIne 41");
			 int rs=((java.sql.Statement) st).executeUpdate("insert into doctor values('"+fname+"','"+lname+"','"+age+"','"+gender+"','"+phno+"','"+id+"','"+pwd+"')");
	            //executeQuery and updateQuery  --->ResultSet
	            
	            
	            out.println("<body bgcolor='orange'>Your details are submitted Successfully!</body>");
	            
	            
	            }catch(Exception exception){
	           	 out.println("DoctorRegistrationServlet.java "+exception);
	           	 }		
			
			
			
			AdminRegistration admin=new AdminRegistration();
			
			admin.setFirstname(fname);
			admin.setLastname(lname);
			admin.setAge(age);
			admin.setGender(gender);
			admin.setPhone(phno);
			admin.setId(id);
			admin.setPassword(pwd);
			
			
			
			//System.out.println("1234567890"+email+" "+phone);
			AdminRegi studentDao=new AdminRegisterDao();
			studentDao.adminRegister(admin);
			System.out.println("<h1> Registered Succesfully!  Login?</h1>");
			out.println("<br><a href='doctorlogin.jsp'>click to login</a>");
			System.out.println("registered");
			
			//response.getWriter().append("Served at: ").append(request.getContextPath());
		}
	protected void doPost(HttpServletRequest request, HttpServletResponse response) throws ServletException, IOException {
		// TODO Auto-generated method stub
		doGet(request, response);
	}


}


