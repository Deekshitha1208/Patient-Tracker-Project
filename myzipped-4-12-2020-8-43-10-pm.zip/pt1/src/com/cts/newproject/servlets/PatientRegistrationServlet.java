package com.cts.newproject.servlets;

import java.io.IOException;
import java.io.PrintWriter;
import java.sql.Connection;
import java.sql.DriverManager;
import java.sql.Statement;

import javax.servlet.ServletException;
import javax.servlet.annotation.WebServlet;
import javax.servlet.http.HttpServlet;
import javax.servlet.http.HttpServletRequest;
import javax.servlet.http.HttpServletResponse;

import com.cts.newproject.dao.AdminRegi;
import com.cts.newproject.dao.AdminRegisterDao;
import com.cts.newproject.dao.PatientRegi;
import com.cts.newproject.dao.PatientRegisterDao;
import com.cts.newproject.model.AdminRegistration;
import com.cts.newproject.model.PatientRegistration;
@WebServlet("/PatientRegistration")
public class PatientRegistrationServlet extends HttpServlet{
private static final long serialVersionUID = 1L;
    public PatientRegistrationServlet() {
        super();
    }
protected void doGet(HttpServletRequest request, HttpServletResponse response) throws ServletException, IOException {
PrintWriter out=response.getWriter();

String url,name,pass;
Connection con=null;
String fname=request.getParameter("fname");
String lname=request.getParameter("lname");
int age=Integer.parseInt(request.getParameter("age"));
String gender=request.getParameter("gender");
long phno=Long.parseLong(request.getParameter("phono"));
String id=request.getParameter("id");
String pwd=request.getParameter("pwd");

try{
Class.forName("com.mysql.jdbc.Driver");

url="jdbc:mysql://localhost:3306/project2";
name="root";
pass="Deekshu@143";
con=DriverManager.getConnection(url,name,pass);
Statement st= ((java.sql.Connection) con).createStatement();

int rs1=((java.sql.Statement) st).executeUpdate("insert into patient values('"+fname+"','"+lname+"','"+age+"','"+gender+"','"+phno+"','"+id+"','"+pwd+"')");  

           
           out.println("<center><body bgcolor='skyblue'>Your details are submitted Successfully!</body></center>");
           
           
           }catch(Exception exception){
          out.println("PatientRegistrationServlet.java "+exception);
          }



PatientRegistration patient=new PatientRegistration();

patient.setFirstname(fname);
patient.setLastname(lname);
patient.setAge(age);
patient.setGender(gender);
patient.setPhone(phno);
patient.setId(id);
patient.setPassword(pwd);
PatientRegi studentDao=new PatientRegisterDao();
studentDao.patientRegister(patient);
System.out.println("<h1> Registered Succesfully!  Login?</h1>");
out.println("<br><a href='patientlogin.jsp'>click to login</a>");
System.out.println("registered");

//response.getWriter().append("Served at: ").append(request.getContextPath());
}
protected void doPost(HttpServletRequest request, HttpServletResponse response) throws ServletException, IOException {
// TODO Auto-generated method stub
doGet(request, response);
}


}


