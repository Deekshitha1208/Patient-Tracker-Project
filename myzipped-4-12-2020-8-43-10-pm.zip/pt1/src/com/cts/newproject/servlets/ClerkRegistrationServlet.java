
package com.cts.newproject.servlets;

import java.io.IOException;
import java.io.PrintWriter;
import java.sql.Connection;
import java.sql.DriverManager;
import java.sql.Statement;

import javax.servlet.ServletException;
import javax.servlet.annotation.WebServlet;
import javax.servlet.http.HttpServlet;
import javax.servlet.http.HttpServletRequest;
import javax.servlet.http.HttpServletResponse;

import com.cts.newproject.dao.ClerkRegi;
import com.cts.newproject.dao.ClerkRegisterDao;
import com.cts.newproject.model.ClerkRegistration;


/**
 * Servlet implementation class ClerkRegistrationServlet
 */
@WebServlet("/ClerkRegistration")
public class ClerkRegistrationServlet extends HttpServlet {
	private static final long serialVersionUID = 1L;
    public ClerkRegistrationServlet() {
        super();
    }
	protected void doGet(HttpServletRequest request, HttpServletResponse response) throws ServletException, IOException {
		PrintWriter out=response.getWriter();
		System.out.println("Line 27");
		String url,name,pass;
		Connection con=null;
		String fname=request.getParameter("fname");
		String lname=request.getParameter("lname");
		int age=Integer.parseInt(request.getParameter("age"));
		String gender=request.getParameter("gender");
		long phno=Long.parseLong(request.getParameter("phono"));
		String id=request.getParameter("id");
		String pwd=request.getParameter("pwd");
		
		try{
			Class.forName("com.mysql.jdbc.Driver");
			//System.out.println("LIne 38");
			url="jdbc:mysql://localhost:3306/project2";
			name="root";
			pass="Deekshu@143";
			 con=DriverManager.getConnection(url,name,pass);
			Statement st= ((java.sql.Connection) con).createStatement();
			//System.out.println("LIne 41");
			// int rs=((java.sql.Statement) st).executeUpdate("insert into admin values('"+fname+"','"+lname+"','"+age+"','"+gender+"','"+phno+"','"+id+"','"+pwd+"')");
			// int rs1=((java.sql.Statement) st).executeUpdate("insert into patient1 values('"+fname+"','"+lname+"','"+age+"','"+gender+"','"+phno+"','"+id+"','"+pwd+"')");
			// int rs2=((java.sql.Statement) st).executeUpdate("insert into doctor values('"+fname+"','"+lname+"','"+age+"','"+gender+"','"+phno+"','"+id+"','"+pwd+"')");
			 int rs3=((java.sql.Statement) st).executeUpdate("insert into clerk values('"+fname+"','"+lname+"','"+age+"','"+gender+"','"+phno+"','"+id+"','"+pwd+"')");
	            //executeQuery and updateQuery  --->ResultSet
	            
	            
	            out.println("<center><body bgcolor='skyblue'>Your details are submitted Successfully!</body></center>");
	            
	            
	            }catch(Exception exception){
	           	 out.println("ClerkRegistrationServlet.java "+exception);
	           	 }		
			
			
			
			ClerkRegistration clerk=new ClerkRegistration();
			
			clerk.setFirstname(fname);
			clerk.setLastname(lname);
			clerk.setAge(age);
			clerk.setGender(gender);
			clerk.setPhone(phno);
			clerk.setId(id);
			clerk.setPassword(pwd);
			
			
			
			//System.out.println("1234567890"+email+" "+phone);
			ClerkRegi studentDao=new ClerkRegisterDao();
			studentDao.clerkRegister(clerk);
			System.out.println("<h1> Registered Succesfully!  Login?</h1>");
			out.println("<br><a href='clerklogin.jsp'>click to login</a>");
			System.out.println("registered");
			
			//response.getWriter().append("Served at: ").append(request.getContextPath());
		}
	protected void doPost(HttpServletRequest request, HttpServletResponse response) throws ServletException, IOException {
		// TODO Auto-generated method stub
		doGet(request, response);
	}


}
