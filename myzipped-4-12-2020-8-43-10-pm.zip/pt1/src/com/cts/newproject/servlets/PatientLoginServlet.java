package com.cts.newproject.servlets;

import java.io.IOException;
import java.io.PrintWriter;
import java.sql.Connection;
import java.sql.DriverManager;
import java.sql.ResultSet;
import java.sql.Statement;

import javax.servlet.ServletException;
import javax.servlet.annotation.WebServlet;
import javax.servlet.http.HttpServlet;
import javax.servlet.http.HttpServletRequest;
import javax.servlet.http.HttpServletResponse;

@WebServlet("/PatientLoginServlet")
public class PatientLoginServlet extends HttpServlet{
private static final long serialVersionUID = 1L;
    public PatientLoginServlet() {
        super();
    }
protected void doGet(HttpServletRequest request, HttpServletResponse response) throws ServletException, IOException {

PrintWriter out=response.getWriter();

String a=request.getParameter("username");
String b=request.getParameter("password");

try{
Class.forName("com.mysql.jdbc.Driver");
Connection con=DriverManager.getConnection("jdbc:mysql://localhost:3306/project2","root","Deekshu@143");
Statement st=con.createStatement();
ResultSet rs1=st.executeQuery("select id,pwd from patient");
int i=0;
while(rs1.next()){
if(a.equals(rs1.getString(1)))              
{
i=1;
if( b.equals( rs1.getString(2) ))            
{
out.println("<center><body bgcolor='orange'>log in successful</body></center>");
out.println("<center><body bgcolor='orange'><br><a href='allpatientiddetails.jsp'><input type='submit' value='view test results'></a><br><a href='homepage.jsp'>Home</a></body></center>");

//out.println("<br><a href='homepage.jsp'>Home</a>");
}
else
{
out.println("password not matching");
}
break;
}
}
if(i==0)
{
out.println("Invalid credentials");
}
}
catch (Exception e){
out.println("patient login Servlet "+e);}




//response.getWriter().append("Served at: ").append(request.getContextPath());
}
protected void doPost(HttpServletRequest request, HttpServletResponse response) throws ServletException, IOException {
doGet(request, response);
}

}


