package com.cts.newproject.servlets;

import java.io.IOException;
import java.io.PrintWriter;
import java.sql.Connection;
import java.sql.DriverManager;
import java.sql.ResultSet;
import java.sql.Statement;

import javax.servlet.ServletException;
import javax.servlet.annotation.WebServlet;
import javax.servlet.http.HttpServlet;
import javax.servlet.http.HttpServletRequest;
import javax.servlet.http.HttpServletResponse;

/**
 * Servlet implementation class BillingServlet
 */
@WebServlet("/BillingServlet")
public class BillingServlet extends HttpServlet {
	private static final long serialVersionUID = 1L;
       
    /**
     * @see HttpServlet#HttpServlet()
     */
    public BillingServlet() {
        super();
        // TODO Auto-generated constructor stub
    }

	/**
	 * @see HttpServlet#doGet(HttpServletRequest request, HttpServletResponse response)
	 */
	protected void doGet(HttpServletRequest request, HttpServletResponse response) throws ServletException, IOException {
		// TODO Auto-generated method stub
		//response.getWriter().append("Served at: ").append(request.getContextPath());
		PrintWriter out=response.getWriter();
		Connection con=null;
		String id1=request.getParameter("id");
		 try{
			 Class.forName("com.mysql.jdbc.Driver");
			 con=DriverManager.getConnection("jdbc:mysql://localhost:3306/project2","root","Deekshu@143");
			 Statement st=con.createStatement();
			 ResultSet rs=st.executeQuery("select distinct id,test,sum(bill) from patientdetails where id='"+id1+"'");
			 out.println("<table border=1><tr><th>Id</th><th>test</th><th>bill</th></tr></table>");
			while(rs.next()){
				 String id=(rs.getString(1));
				String test=rs.getString(2);
				int bill=Integer.parseInt( rs.getString(3));
				 //int price=Integer.parseInt(rs.getString(4));
				 out.println("<body bgcolor='orange'><table border=1><tr><td>"+id+"</td><td>"+test+"</td><td>"+bill+"</td></tr></body>");
				
			 }
			out.println("</table");
			 
		 }
		 catch(Exception e){
			 out.println("view servlet"+e);
		 }
		 out.println("<br><a href='homepage.jsp'><input type='button' value='logoff'></a>");
		 out.println("<br><a href='help.jsp'><input type='button' value='help'></a>");

	}

	/**
	 * @see HttpServlet#doPost(HttpServletRequest request, HttpServletResponse response)
	 */
	protected void doPost(HttpServletRequest request, HttpServletResponse response) throws ServletException, IOException {
		// TODO Auto-generated method stub
		doGet(request, response);
	}

}
