package com.cts.newproject.servlets;

import java.io.IOException;
import java.io.PrintWriter;
import java.sql.Connection;
import java.sql.DriverManager;
import java.sql.ResultSet;
import java.sql.Statement;

import javax.servlet.ServletException;
import javax.servlet.annotation.WebServlet;
import javax.servlet.http.HttpServlet;
import javax.servlet.http.HttpServletRequest;
import javax.servlet.http.HttpServletResponse;

/**
 * Servlet implementation class UpdateDietServlet
 */
@WebServlet("/UpdateDietServlet")
public class UpdateDietServlet extends HttpServlet {
	private static final long serialVersionUID = 1L;
       
    /**
     * @see HttpServlet#HttpServlet()
     */
    public UpdateDietServlet() {
        super();
        // TODO Auto-generated constructor stub
    }

	/**
	 * @see HttpServlet#doGet(HttpServletRequest request, HttpServletResponse response)
	 */
	protected void doGet(HttpServletRequest request, HttpServletResponse response) throws ServletException, IOException {
		// TODO Auto-generated method stub
		
	//response.getWriter().append("Served at: ").append(request.getContextPath());
		PrintWriter out=response.getWriter();
		Connection con=null;
		int i=0,j=0;
		String id=request.getParameter("id");
		String test=request.getParameter("test");
	;
		int bill=Integer.parseInt(request.getParameter("bill"));
		String diet=request.getParameter("diet");
		try{
			Class.forName("com.mysql.jdbc.Driver");
			con=DriverManager.getConnection("jdbc:mysql://localhost:3306/project2","root","Deekshu@143");
			Statement st=con.createStatement();
			  ResultSet rs=st.executeQuery("select id,test from patientdetails3");
			   while(rs.next()){
				   if(id.equals(rs.getString(1)) && test.equals(rs.getString(2))){
					   j=1;
			
					   
							   st.executeUpdate("update patientdetails3 set diet='"+diet+"'where id='"+id+"'");
							   out.println("updated succesfully");
							// out.println("<a href='adddiet.jsp'>Add Diet</a>");
							   out.println("<br><body bgcolor='orange'><br><a href='homepage.jsp'><input type='submit' value='Home'></a></body>");
							   i=1;
						   }
					   }
					
			   
			   if(j==0)
				   out.println("id not exist");
			   con.close();
						
		}
		catch(Exception e)
		{
			//out.println("Found Exception"+e);
		}
	
	}

	/**
	 * @see HttpServlet#doPost(HttpServletRequest request, HttpServletResponse response)
	 */
	protected void doPost(HttpServletRequest request, HttpServletResponse response) throws ServletException, IOException {
		// TODO Auto-generated method stub
		doGet(request, response);
	}

}
