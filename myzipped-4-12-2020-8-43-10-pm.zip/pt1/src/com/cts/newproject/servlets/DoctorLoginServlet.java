package com.cts.newproject.servlets;

import java.io.IOException;
import java.io.PrintWriter;
import java.sql.Connection;
import java.sql.DriverManager;
import java.sql.ResultSet;
import java.sql.Statement;

import javax.servlet.ServletException;
import javax.servlet.annotation.WebServlet;
import javax.servlet.http.HttpServlet;
import javax.servlet.http.HttpServletRequest;
import javax.servlet.http.HttpServletResponse;

@WebServlet("/DoctorLoginServlet")
public class DoctorLoginServlet extends HttpServlet {
	private static final long serialVersionUID = 1L;
    public DoctorLoginServlet() {
        super();
    }
	protected void doGet(HttpServletRequest request, HttpServletResponse response) throws ServletException, IOException {
		
		PrintWriter out=response.getWriter();

		String a=request.getParameter("username");
		String b=request.getParameter("password");
		
		try{
			Class.forName("com.mysql.jdbc.Driver");
			Connection con=DriverManager.getConnection("jdbc:mysql://localhost:3306/project2","root","Deekshu@143");
			Statement st=con.createStatement();
			ResultSet rs=st.executeQuery("select id,pwd from doctor");
			int i=0;
			while(rs.next()){
			 if(a.equals(rs.getString(1)))                //  if(a.equals( rs.getString("VendorId") )  )
				{
					i=1;
					if( b.equals( rs.getString(2) ))              //   if(a.equals( rs.getString("Password") )  )
					{
					out.println("<center><body bgcolor='orange'>log in successful<br><a href='allpatientiddetails.jsp'><input type='submit' value='view patient details'></a><br><br><a href='homepage.jsp'>Home</a></body></center>");
					//out.println("<a href='allpatientiddetails.jsp'>view test requests</a>");
					
					
					//out.println("<br><a href='homepage.jsp'>Home</a>");
					}
					else 
					{
						out.println("password not matching");
					}
					break;
				}
			}
			if(i==0) 
			{
			out.println("Id doesn't exixts");
			}
		}
		catch (Exception e){
			out.println("doctor login Servlet "+e);}


		
		
		//response.getWriter().append("Served at: ").append(request.getContextPath());
	}
	protected void doPost(HttpServletRequest request, HttpServletResponse response) throws ServletException, IOException {
		doGet(request, response);
	}

}

