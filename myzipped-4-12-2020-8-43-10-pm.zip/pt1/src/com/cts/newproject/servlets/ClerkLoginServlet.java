package com.cts.newproject.servlets;

import java.io.IOException;
import java.io.PrintWriter;
import java.sql.Connection;
import java.sql.DriverManager;
import java.sql.ResultSet;
import java.sql.Statement;

import javax.servlet.ServletException;
import javax.servlet.annotation.WebServlet;
import javax.servlet.http.HttpServlet;
import javax.servlet.http.HttpServletRequest;
import javax.servlet.http.HttpServletResponse;

/**
 * Servlet implementation class ClerkLoginServlet
 */
@WebServlet("/ClerkLoginServlet")
public class ClerkLoginServlet extends HttpServlet {
	private static final long serialVersionUID = 1L;
    public ClerkLoginServlet() {
        super();
    }
	protected void doGet(HttpServletRequest request, HttpServletResponse response) throws ServletException, IOException {
		
		PrintWriter out=response.getWriter();

		String a=request.getParameter("username");
		String b=request.getParameter("password");
		
		try{
			Class.forName("com.mysql.jdbc.Driver");
			Connection con=DriverManager.getConnection("jdbc:mysql://localhost:3306/project2","root","Deekshu@143");
			Statement st=con.createStatement();
			ResultSet rs3=st.executeQuery("select id,pwd from clerk");
			int i=0;
			while(rs3.next()){
			 if(a.equals(rs3.getString(1)))                //  if(a.equals( rs.getString("VendorId") )  )
				{
					i=1;
					if( b.equals( rs3.getString(2) ))              //   if(a.equals( rs.getString("Password") )  )
					{
					out.println("<center><body bgcolor='skyblue'>log in successful</body></center>");
					out.println("<br><br><center><body bgcolor='skyblue'><a href='allpatientdetails.jsp'><input type='submit' value='All patient Details'></a><br><br><a href='homepage.jsp'><input type='submit' value='Home'></a></body></center>");
					
					//out.println("<center><br><a href='homepage.jsp'><input type='submit' value='Home'></a></center>");
					}
					else 
					{
						out.println("password not matching");
					}
					break;
				}
			}
			if(i==0) 
			{
			out.println("Id doesn't exixts");
			}
		}
		catch (Exception e){
			out.println("clerk login Servlet "+e);}


		
		
		//response.getWriter().append("Served at: ").append(request.getContextPath());
	}
	protected void doPost(HttpServletRequest request, HttpServletResponse response) throws ServletException, IOException {
		doGet(request, response);
	}
}





